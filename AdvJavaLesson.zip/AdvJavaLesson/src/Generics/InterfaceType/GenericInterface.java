package Generics.InterfaceType;

public interface GenericInterface<T>{
    void setValue(T t);
    T getValue();

}
