package Generics.InterfaceType;

public class GenericClassStringImpl implements GenericInterface<String>{
    @Override
    public void setValue(String s) {

    }

    @Override
    public String getValue() {
        return null;
    }
}
